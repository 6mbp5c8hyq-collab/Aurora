# AURORA Safari PWA

Safari-first PWA front end for AURORA. It avoids the previous iPhone failure mode by not storing full solver results in localStorage and by using a service worker that never returns `null` from `respondWith`.

## Default canonical backend
https://todo-app-production-afcc.up.railway.app

Endpoints wired:
- GET /api/health
- POST /api/validate
- POST /api/jobs
- GET /api/jobs/{job_id}

## Deploy
Upload the folder to any HTTPS static host. On iPhone open the HTTPS URL in Safari, Share → Add to Home Screen.

## Storage model
IndexedDB stores project data and small run metadata only. Full execution responses remain in memory and are exported directly.

## Same-origin production proxy
The Railway deployment serves the PWA and proxies `/api/*` to the canonical AURORA backend, avoiding Safari CORS and cross-origin storage problems.
